package com.example.demo.dto;

import lombok.*;

// CK로 이미지를 업로드했을 때의 응답 객체 (변경할 수 없음)
@Data
@AllArgsConstructor
public class CKResponse {
	// 업로드한 파일의 개수
	private Integer uploaded;
	// 업로드한 파일의 이름
	private String fileName;
	// 업로드 주소
	private String url;
}
