package com.example.demo.controller;

import java.io.*;
import java.nio.file.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.*;

import com.example.demo.entity.*;
import com.example.demo.service.*;

@Controller
public class ProductController {
	@Autowired
	private ProductService service;
	@Value("c:/upload/image")
	private String UploadFolder;
	
	
	// ck이미지 업로드를 처리할 컨트롤러
	@PostMapping(value="/api/products/image", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<?> ckImageUpload(MultipartFile upload) {
		return ResponseEntity.ok(service.ckImageUpload(upload));
	}
	
	@GetMapping(path="/api/images/{imagename}", produces=MediaType.APPLICATION_OCTET_STREAM_VALUE)
	public ResponseEntity<byte[]> showProfile(@PathVariable String imagename) {
		File file = new File(UploadFolder, imagename);
		if(file.exists()==false)
			return null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.IMAGE_JPEG);
		headers.add("Content-Disposition", "inline;filename="+imagename);
		try {
			return ResponseEntity.ok().headers(headers)
					.body(Files.readAllBytes(file.toPath()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	@PostMapping("/api/products/new")
	public ResponseEntity<Integer> write(Product product) {
		System.out.println("=============================");
		System.out.println(product);
		System.out.println("=============================");
		return ResponseEntity.ok(service.add(product));
	}
	
	@GetMapping("/api/products")
	public ResponseEntity<Product> read(Integer pno) {
		return ResponseEntity.ok(service.read(pno));
	}
	
}
