package com.example.demo.controller;

import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

@Controller
public class ViewController {
	@GetMapping("/")
	public String index() {
		return "index";
	}
	
	// 상품 등록 페이지로 이동
	@GetMapping("/product/write")
	public void product_write() {
	}
	
	// 상품 보기 페이지로 이동
	@GetMapping("/product/read")
	public void product_read() {
	}
}
