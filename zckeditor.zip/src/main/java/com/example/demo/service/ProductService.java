package com.example.demo.service;

import java.io.*;
import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;
import org.springframework.web.multipart.*;

import com.example.demo.dto.*;
import com.example.demo.entity.*;

@Service
public class ProductService {
	@Value("c:/upload/image")
	private String UploadFolder;
	@Value("http://localhost:8087/api/images/")
	private String uploadPath;
	
	// DAO를 대신해 상품 정보를 저장하기 위한 테스트용 상품 번호와 상품 리스트 만들기
	private Integer pno = 1;
	private List<Product> list = new ArrayList<>();
	
	// 이미지 파일을 저장하고 사전에 정해진 ckeditor 형식으로 리턴하는 서비스
	public CKResponse ckImageUpload(MultipartFile upload) {
		if(upload!=null && upload.isEmpty()==false && upload.getContentType().toLowerCase().startsWith("image/")) {
			// 파일 이름이 겹칠 수 있으므로 UUID를 이용해 파일명을 변경한 다음 저장한다
			// 이미지의 종류는 일단 무조건 jpg로 간주하겠다
			String imageName = UUID.randomUUID().toString() + ".jpg";
			File file = new File(UploadFolder, imageName);
			try {
				upload.transferTo(file);
			} catch (IllegalStateException | IOException e) {
				e.printStackTrace();
			}
			return new CKResponse(1, imageName, uploadPath + imageName);
		}
		return null;
	}
	
	public Integer add(Product product) {
		product.setPno(pno);
		list.add(product);
		return pno++;
	}
	
	public Product read(Integer pno) {
		return list.get(pno-1);
	}
}
