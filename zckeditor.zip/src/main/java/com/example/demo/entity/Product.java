package com.example.demo.entity;

import lombok.*;

@Data
public class Product {
	private Integer pno;
	private String name;
	private String info;
}
